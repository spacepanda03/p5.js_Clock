let walk,caught,BackGround;
let resources = {
  walkImg: [],
  caughtImg: [],
  background1:[],
  day:[],
  light:[],
  moon:[],
  night:[],
  shadow:[],
  sun:[],
  sound:[]
}
function preload() {//load images and sound.
  resources.caughtImg = loadImage("asset/caught/caught.png");
  resources.background1 = loadImage("asset/background/background1.png");
  resources.day = loadImage("asset/background/day.png");
  resources.light = loadImage("asset/background/light.png");
  resources.moon = loadImage("asset/background/moon.png");
  resources.night = loadImage("asset/background/night.png");
  resources.shadow = loadImage("asset/background/shadow.png");
  resources.sun = loadImage("asset/background/sun.png");
  resources.sound = loadSound("asset/sound/konata.mp3");
  for (let i = 0; i < 24; i++){
    resources.walkImg[i] = loadImage("asset/walk/walk" + i + ".png");
  } //The walking image is a sequence image, so I use a loop statement here to achieve the playback effect.
}

class Caught { //Set the parameters of the caught image.
  constructor(caughtImg){
    this.position = [width*0.5, height*0.8];
    this.image = caughtImg;
    }
  run = function () {
    this.showWalk();

  }
  showWalk(){
      imageMode(CENTER);
      image(this.image,this.position[0],this.position[1],180,180); 
}
}

class KonataWalk {//Set the parameters of the character.
  constructor(walkImg) {
    this.vector_factor_x = 1
    this.vector_factor_y = 1
    this.position = [width * 0.5, height * 0.8];
    this.image = walkImg;
  }
    run = function () {
    this.showWalk();
  }
    showWalk(){
    if(mouseIsPressed){
      push();
      tint(255, 0);
      pop();
    }else{
    let index = Math.floor(frameCount) % this.image.length;
    imageMode(CENTER);
    if (this.vector_factor_x > 0) {
      push();
      scale(-1, 1);//Set the character flip
      image(this.image[index], -this.position[0], this.position[1],100,100);
      pop();//At the same time as the character is flipped, the position will also be reversed, so the X-axis parameter needs to be set to a negative number.
    }
    else {
      push();
      image(this.image[index], this.position[0], this.position[1],100,100);
    }
    pop();
  }
  }
}
function mousePressed(){//When the mouse is pressed, a sound will play.
  resources.sound.playMode('restart');
  resources.sound.play();
}

function setup() {
   createCanvas(500, 500);
  frameRate(24);//set fps = 24.
    walk = new KonataWalk(resources.walkImg);
  caught = new Caught(resources.caughtImg);
 resources.sound.playMode('sustain');
  resources.sound.play();
}


function draw() {
  background(150,100,20);
  imageMode(CENTER);
  image(resources.day,width * 0.5, height * 0.5,500,500);


  let h = hour();
  let m = minute();
//The following is determined by judging whether it is day or night, and whether the sun or moon has risen.
  if(h<6){
    image(resources.night,width * 0.5, height * 0.5,500,500);
   
  }
  if(h==6){
    push()
    tint(255,255/60*(60-(m+1)));
    image(resources.night,width * 0.5, height * 0.5,500,500);
    pop();
  }
  if(h==6){
    push()
    translate(300-300/60*(m+1),50-50/60*(m+1));
    image(resources.sun,width * 0.5, height * 0.5,500,500);
    pop();
   }
   if(h>6&&h<17){
    push()
    image(resources.sun,width * 0.5, height * 0.5,500,500);
    pop();
   }
   if(h==17){
    push()
    translate(0-300/60*(m+1),50/60*(m));
    image(resources.sun,width * 0.5, height * 0.5,500,500);
    pop();
   }
  if(h==17){
    push()
    tint(255,255/60*(m+1));
    image(resources.night,width * 0.5, height * 0.5,500,500);
    pop();
  }
  if(h>17){
    image(resources.night,width * 0.5, height * 0.5,500,500);
  }
 if(h==17){
  push()
  translate(300-300/60*(m+1),50-50/60*(m+1));
  image(resources.moon,width * 0.5, height * 0.5,500,500);
  pop();
 }
 if(h>17||h<3){
  push()
  image(resources.moon,width * 0.5, height * 0.5,500,500);
  pop();
 }
 if(h==3){
  push()
  translate(0-300/60*(m+1),50/60*(m));
  image(resources.moon,width * 0.5, height * 0.5,500,500);
  pop();
 }
  image(resources.background1,width * 0.5, height * 0.5,500,500);//The buildings and streets need to be placed before the sky layer.
  //Due to the lighting, the light at night will be very dark, so I added a layer of black to reduce the brightness of the buildings and streets.↓
  if(h<6){
    push();
    tint(255,200);
    image(resources.shadow,width * 0.5, height * 0.5,500,500);
    pop();

  }  
  if(h==6){
    push();
    tint(255,200-(m*3.3));
    image(resources.shadow,width * 0.5, height * 0.5,500,500);
    pop();
  }
  if(h==17){
    push()
    tint(255,200/60*(m+1));
    image(resources.shadow,width * 0.5, height * 0.5,500,500);
    pop();
  }
  if(h>17){
    push();
    tint(255,200);
    image(resources.shadow,width * 0.5, height * 0.5,500,500);
    pop();
  }
  if(h>=18 && h<=23){//In order to simulate the situation where people turn on the lights at night, I added another layer of bright light.↓
    image(resources.light,width * 0.5, height * 0.5,500,500);
  }
  //The character needs to be displayed on the top layer, so the character class is run here.↓
  walk.run();
  if (mouseIsPressed) {
    caught.run();
    if (mouseY>366){//Limit the character’s activity on the street.
    caught.position[1] = mouseY;
    walk.position[1] = mouseY;
    }else{
      caught.position[1] = 365;
      walk.position[1] = 365;
    }
    caught.position[0] = mouseX;
    walk.position[0] = mouseX;
    
  } else {
    walk.position[0] += walk.vector_factor_x;
    walk.position[1] += walk.vector_factor_y;
    if (walk.position[0] > width-30 || walk.position[0] < 30) {
      walk.vector_factor_x *= -1;
    }
    if (walk.position[1] > height-40 || walk.position[1] < 366) {
      walk.vector_factor_y *= -1;
    }
  }
}